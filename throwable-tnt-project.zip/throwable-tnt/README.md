# Throwable TNT (Fabric, Minecraft 26.3)

Бросаемый динамит: ПКМ — бросок по направлению взгляда, взрыв через 3 сек или при ударе о блок/существо.
Мощность взрыва 7.0 (обычный TNT = 4.0) — меняется в `ThrownTntEntity.EXPLOSION_POWER`.

## Сборка
Нужны: JDK 25 и доступ в интернет (Loom скачает Minecraft и Fabric API).

    ./gradlew build          # Windows: gradlew.bat build

Готовый мод: `build/libs/throwable-tnt-1.0.0.jar` (файл `-sources.jar` не нужен).
Положите его в `mods/` вместе с Fabric API 0.165.0+26.3 и Fabric Loader 0.19.5+.

Тест в игре: `./gradlew runClient`.

## Рецепт
    F G .      F = огненный заряд, G = порох,
    P T P      P = бумага, T = TNT
    . G F      Результат: 2 шт.
