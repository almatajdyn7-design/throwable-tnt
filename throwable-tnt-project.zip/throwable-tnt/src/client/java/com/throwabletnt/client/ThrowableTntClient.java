package com.throwabletnt.client;

import com.throwabletnt.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;

public class ThrowableTntClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Летящий динамит рисуется как плоский предмет (модель/текстура из ресурсов)
        EntityRenderers.register(ModEntities.THROWN_TNT, ThrownItemRenderer::new);
    }
}
