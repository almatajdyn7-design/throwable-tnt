package com.throwabletnt.item;

import com.throwabletnt.entity.ThrownTntEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ThrowableTntItem extends Item {
    /** Скорость броска (снежок = 1.5). */
    private static final float THROW_VELOCITY = 1.2F;

    public ThrowableTntItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.TNT_PRIMED, SoundSource.PLAYERS, 1.0F, 1.0F);

        if (level instanceof ServerLevel serverLevel) {
            // Бросок строго по направлению взгляда игрока (работает одинаково
            // для первого и третьего лица — направление берётся от головы игрока).
            Projectile.spawnProjectileFromRotation(
                    ThrownTntEntity::new, serverLevel, stack, player, 0.0F, THROW_VELOCITY, 1.0F);
        }

        player.awardStat(Stats.ITEM_USED.get(this));
        stack.consume(1, player);
        return InteractionResult.SUCCESS;
    }
}
