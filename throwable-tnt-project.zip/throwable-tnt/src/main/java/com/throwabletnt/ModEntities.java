package com.throwabletnt;

import com.throwabletnt.entity.ThrownTntEntity;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
    public static final ResourceKey<EntityType<?>> THROWN_TNT_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, ThrowableTntMod.id("throwable_tnt"));

    public static final EntityType<ThrownTntEntity> THROWN_TNT = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            THROWN_TNT_KEY,
            EntityType.Builder.<ThrownTntEntity>of(ThrownTntEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(THROWN_TNT_KEY));

    private ModEntities() {}

    /** Вызов нужен, чтобы класс загрузился и сущность зарегистрировалась. */
    public static void register() {}
}
