package com.throwabletnt.entity;

import com.throwabletnt.ModEntities;
import com.throwabletnt.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Брошенный динамит: взрывается через 3 секунды (60 тиков) или сразу при ударе.
 */
public class ThrownTntEntity extends ThrowableItemProjectile {
    /** 3 секунды * 20 тиков. */
    public static final int FUSE_TICKS = 60;

    /** Мощность взрыва. Обычный TNT = 4.0. Здесь заметно мощнее. */
    public static final float EXPLOSION_POWER = 7.0F;

    public ThrownTntEntity(EntityType<? extends ThrownTntEntity> type, Level level) {
        super(type, level);
    }

    /** Используется при броске игроком (через Projectile.spawnProjectileFromRotation). */
    public ThrownTntEntity(Level level, LivingEntity owner, ItemStack stack) {
        super(ModEntities.THROWN_TNT, owner, level, stack);
    }

    public ThrownTntEntity(Level level, double x, double y, double z, ItemStack stack) {
        super(ModEntities.THROWN_TNT, x, y, z, level, stack);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.THROWABLE_TNT;
    }

    @Override
    public void tick() {
        super.tick();

        if (level().isClientSide()) {
            // Дымок и искры от горящего фитиля
            level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.3, getZ(), 0.0, 0.0, 0.0);
            level().addParticle(ParticleTypes.FLAME, getX(), getY() + 0.25, getZ(), 0.0, 0.02, 0.0);
            return;
        }

        // Шипение фитиля раз в секунду
        if (tickCount % 20 == 0 && tickCount > 0) {
            level().playSound(null, getX(), getY(), getZ(),
                    SoundEvents.TNT_PRIMED, SoundSource.NEUTRAL, 0.6F, 1.0F + tickCount * 0.005F);
        }

        if (tickCount >= FUSE_TICKS) {
            detonate();
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult hit) {
        super.onHitBlock(hit);
        detonate(); // столкновение с блоком — взрыв сразу
    }

    @Override
    protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);
        detonate(); // попадание в существо — тоже сразу
    }

    private void detonate() {
        if (isRemoved()) {
            return;
        }
        if (level() instanceof ServerLevel serverLevel) {
            // Настоящий взрыв: урон существам + разрушение блоков, как у TNT
            serverLevel.explode(this, getX(), getY(0.0625), getZ(),
                    EXPLOSION_POWER, Level.ExplosionInteraction.TNT);
            discard();
        }
    }
}
