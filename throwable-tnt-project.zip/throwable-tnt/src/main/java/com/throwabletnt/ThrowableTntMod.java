package com.throwabletnt;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class ThrowableTntMod implements ModInitializer {
    public static final String MOD_ID = "throwable_tnt";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.register();
        ModItems.register();
    }
}
