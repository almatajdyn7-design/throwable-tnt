package com.throwabletnt;

import com.throwabletnt.item.ThrowableTntItem;
import java.util.List;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.ItemLore;

public final class ModItems {
    public static final ResourceKey<Item> THROWABLE_TNT_KEY =
            ResourceKey.create(Registries.ITEM, ThrowableTntMod.id("throwable_tnt"));

    public static final Item THROWABLE_TNT = Registry.register(
            BuiltInRegistries.ITEM,
            THROWABLE_TNT_KEY,
            new ThrowableTntItem(new Item.Properties()
                    .setId(THROWABLE_TNT_KEY)
                    .stacksTo(16)
                    // Описание предмета (русский/английский текст берётся из lang-файлов)
                    .component(DataComponents.LORE, new ItemLore(List.of(
                            Component.translatable("item.throwable_tnt.throwable_tnt.desc"))))));

    private ModItems() {}

    public static void register() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT)
                .register(output -> output.accept(THROWABLE_TNT));
    }
}
